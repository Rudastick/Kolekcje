package pl.kurs.list.homework07.model;

public class Cosmetic extends Product{
    public Cosmetic(String name, double price) {
        super(name, price);
    }
}
