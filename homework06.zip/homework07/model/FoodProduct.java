package pl.kurs.list.homework07.model;

public class FoodProduct extends Product{
    public FoodProduct(String name, double price) {
        super(name, price);
    }
}
