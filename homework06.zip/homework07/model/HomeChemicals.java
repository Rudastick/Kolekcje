package pl.kurs.list.homework07.model;

public class HomeChemicals extends Product{
    public HomeChemicals(String name, double price) {
        super(name, price);
    }
}
