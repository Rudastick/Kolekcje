package pl.kurs.list.homework07.model;

public class Tools extends Product{
    public Tools(String name, double price) {
        super(name, price);
    }
}
